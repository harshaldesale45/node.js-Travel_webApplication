var express=require("express");
var bodyParser= require("body-parser");
var app =express();

app.use(bodyParser.urlencoded({extended :true}));
app.set("view engine" , "ejs");

app.get("/" , function(req, res){
    res.render("landing");
});

var campgrounds = [
       {name :"Himachal" , image :"https://cdn.pixabay.com/photo/2014/11/27/18/36/tent-548022__340.jpg"},
        {name :"Babadas" , image :"https://cdn.pixabay.com/photo/2015/07/10/17/24/night-839807__340.jpg"},
        {name :"Babadas" , image :"https://cdn.pixabay.com/photo/2015/07/10/17/24/night-839807__340.jpg"},
        {name :"Himachal" , image :"https://cdn.pixabay.com/photo/2014/11/27/18/36/tent-548022__340.jpg"},
        {name :"Babadas" , image :"https://cdn.pixabay.com/photo/2015/07/10/17/24/night-839807__340.jpg"},
        {name :"Babadas" , image :"https://cdn.pixabay.com/photo/2015/07/10/17/24/night-839807__340.jpg"},
        {name :"Himachal" , image :"https://cdn.pixabay.com/photo/2014/11/27/18/36/tent-548022__340.jpg"},
        {name :"Babadas" , image :"https://cdn.pixabay.com/photo/2015/07/10/17/24/night-839807__340.jpg"},
        {name :"Babadas" , image :"https://cdn.pixabay.com/photo/2015/07/10/17/24/night-839807__340.jpg"}
       ];
       

app.get("/campgrounds" ,function(req ,res){
   res.render("campgrounds", {campgrounds : campgrounds});
});

app.post("/campgrounds" , function(req,res){
    var name= req.body.name;
    var image= req.body.image;
    var object={name :name , image: image};
    campgrounds.push(object);
    res.redirect("/campgrounds");
    
});

 app.get("/campgrounds/new" ,function(req,res){
    res.render("new"); 
 });

app.listen(process.env.PORT , process.env.IP ,function(){
    console.log("Server movie  has started");
    });
    
    