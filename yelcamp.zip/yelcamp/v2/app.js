var express=require("express");
var bodyParser= require("body-parser");
var app =express();
var mongoose = require("mongoose");


mongoose.connect("mongodb://localhost/yelp_camp");
app.use(bodyParser.urlencoded({extended :true}));
app.set("view engine" , "ejs");

// schema setup 
var campgroundSchema =new mongoose.Schema({
   name :String,
   image : String,
   desc : String 
});

var Campground = mongoose.model("Campground" ,campgroundSchema);

Campground.create(
    {
       name :"Himachal" , image :"https://cdn.pixabay.com/photo/2014/11/27/18/36/tent-548022__340.jpg" , desc : "it is a very sweet campground and i like it so much"
    }, function(err ,campground){
        if(err){
            console.log(err);
        }
        else{
            console.log("All Campground");
            console.log(campground);
        }
        // body...
    });

app.get("/" , function(req, res) {
   res.render("landing"); 
});

app.get("/campgrounds" ,function(req ,res){
   // get all campgroung from db
   Campground.find({} ,function(err , allCampgrounds){
       if(err){
           console.log(err);
       }
       else{
           res.render("index", {campgrounds : allCampgrounds});
       }
   });
});

app.post("/campgrounds" , function(req,res){
    var name= req.body.name;
    var image= req.body.image;
    var desc=req.body.desc;
    var newcampground={name :name , image: image , desc: desc};
    Campground.create(newcampground , function(err , newly){
       if(err){
           console.log(err);
       } 
       else{
           console.log("here it is");
           res.redirect("/campgrounds");
           }
       
    });
 });

 app.get("/campgrounds/new" ,function(req,res){
    res.render("new"); 
 });
 
app.get("/campground/:id" , function(req, res) {
    Campground.findById(req.params.id , function(err , foundCampground){
        if(err){
            console.log(err);
        }
        else{
             res.render("show" , {campground : foundCampground}); 
        }
  });
});

app.listen(process.env.PORT , process.env.IP ,function(){
    console.log("Server movie  has started");
    });
    
    